import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class Tester {

    @Test
    @DisplayName("Test0")
    void test0() {
        Initialiser.main(new String[]{"in/test0.txt", "out/test0.txt"});
    }

    @Test
    @DisplayName("Test1")
    void test1() {
        Initialiser.main(new String[]{"in/test1.txt", "out/test1.txt"});
    }

    @Test
    @DisplayName("Test2")
    void test2() {
        Initialiser.main(new String[]{"in/test2.txt", "out/test2.txt"});
    }

    @Test
    @DisplayName("Test3")
    void test3() {
        Initialiser.main(new String[]{"in/test3.txt", "out/test3.txt"});
    }

    @Test
    @DisplayName("Test4")
    void test4() {
        Initialiser.main(new String[]{"in/test4.txt", "out/test4.txt"});
    }

    @Test
    @DisplayName("Test5")
    void test5() {
        Initialiser.main(new String[]{"in/test5.txt", "out/test5.txt"});
    }

    @Test
    @DisplayName("Test6")
    void test6() {
        Initialiser.main(new String[]{"in/test6.txt", "out/test6.txt"});
    }

    @Test
    @DisplayName("Test7")
    void test7() {
        Initialiser.main(new String[]{"in/test7.txt", "out/test7.txt"});
    }

    @Test
    @DisplayName("Test8")
    void test8() {
        Initialiser.main(new String[]{"in/test8.txt", "out/test8.txt"});
    }
    @Test
    @DisplayName("Test9")
    void test9() {
        Initialiser.main(new String[]{"in/test9.txt", "stdout"});
    }
}
